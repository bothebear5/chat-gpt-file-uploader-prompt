// Set the value of GlobalWorkerOptions.workerSrc property to the URL of the local pdf.worker.min.js file
if (typeof window !== "undefined" && "pdfjsLib" in window) {
  window["pdfjsLib"].GlobalWorkerOptions.workerSrc =
    chrome.runtime.getURL("pdf.worker.min.js");
}

// Load Mammoth.js library
const script = document.createElement("script");
script.src = chrome.runtime.getURL("mammoth.browser.min.js");
document.head.appendChild(script);

// Create the button
const button = document.createElement("button");
button.innerText = "Submit File";
button.style.backgroundColor = "green";
button.style.color = "white";
button.style.padding = "3px";
button.style.border = "none";
button.style.borderRadius = "3px";
button.style.margin = "3px";

// Create the progress bar container
const progressContainer = document.createElement("div");
progressContainer.style.width = "99%";
progressContainer.style.height = "5px";
progressContainer.style.backgroundColor = "grey";
progressContainer.style.margin = "3px";
progressContainer.style.borderRadius = "5px";

// Create the progress bar element
const progressBar = document.createElement("div");
progressBar.style.width = "0%";
progressBar.style.height = "100%";
progressBar.style.backgroundColor = "#32a9db";
progressContainer.appendChild(progressBar);

// Create the chunk size input
const chunkSizeInput = document.createElement("input");
chunkSizeInput.type = "number";
chunkSizeInput.min = "1";
chunkSizeInput.value = "5000";
chunkSizeInput.style.margin = "3px";
chunkSizeInput.style.width = "80px";
chunkSizeInput.style.height = "28px";
chunkSizeInput.style.color = "black";
chunkSizeInput.style.fontSize = "14px";

// Create the prompt input
const promptInput = document.createElement("input");
promptInput.type = "text";
promptInput.placeholder = "Enter Text Prompt";
promptInput.style.margin = "3px";
promptInput.style.width = "250px";
promptInput.style.height = "28px";
promptInput.style.color = "black";
promptInput.style.fontSize = "14px";

// Create the chunk size label
const chunkSizeLabel = document.createElement("label");
chunkSizeLabel.innerText = "Chunk Size: ";
chunkSizeLabel.appendChild(chunkSizeInput);
chunkSizeLabel.style.color = "white";

// Create the prompt label
const promptLabel = document.createElement("label");
promptLabel.innerText = "Prompt: ";
promptLabel.appendChild(promptInput);
promptLabel.style.color = "white";

// Add a click event listener to the button
button.addEventListener("click", async () => {
  // Create the input element
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".txt,.js,.py,.html,.css,.json,.csv,.pdf,.doc,.docx";

  // Add a change event listener to the input element
  input.addEventListener("change", async () => {
    progressBar.style.width = "0%";
    progressBar.style.backgroundColor = "#32a9db";

    const file = input.files[0];
    let text;
    if (file.type === "application/pdf") {
      text = await extractTextFromPdfFile(file);
    } else if (
      file.type === "application/msword" ||
      file.type ===
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      text = await extractTextFromWordFile(file);
    } else {
      text = await file.text();
    }
    const chunkSize = parseInt(chunkSizeInput.value);
    const prompt = promptInput.value.trim();

    const numChunks = Math.ceil(text.length / chunkSize);
    for (let i = 0; i < numChunks; i++) {
      const chunk = text.slice(i * chunkSize, (i + 1) * chunkSize);
      const formattedChunk = `${prompt} ${chunk}`;

      await submitConversation(formattedChunk, i + 1, file.name);

      progressBar.style.width = `${((i + 1) / numChunks) * 100}%`;

      let chatgptReady = false;
      while (!chatgptReady) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
        chatgptReady = !document.querySelector(
          ".text-2xl > span:not(.invisible)"
        );
      }
    }

    progressBar.style.backgroundColor = "#32a9db";
  });

  input.click();
});

// Define a function that extracts text from a PDF file using pdf.js library and window['pdfjsLib'] object reference
async function extractTextFromPdfFile(file) {
  const pdfDataUrl = URL.createObjectURL(file);
  const pdfDoc = await window["pdfjsLib"].getDocument(pdfDataUrl).promise;
  let textContent = "";
  for (let i = 1; i <= pdfDoc.numPages; i++) {
    const page = await pdfDoc.getPage(i);
    const pageTextContent = await page.getTextContent();
    textContent += pageTextContent.items.map((item) => item.str).join(" ");
  }
  return textContent;
}

// Define the extractTextFromWordFile function
async function extractTextFromWordFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = function (event) {
      const arrayBuffer = event.target.result;
      const options = { includeDefaultStyleMap: true };
      window.mammoth
        .extractRawText({ arrayBuffer }, options)
        .then((result) => {
          const text = result.value;
          resolve(text);
        })
        .catch((error) => {
          reject(error);
        });
    };
    reader.onerror = function (event) {
      reject(new Error("Error occurred while reading the Word file."));
    };
    reader.readAsArrayBuffer(file);
  });
}

// Define the submitConversation function
async function submitConversation(text, part, filename) {
  const textarea = document.querySelector("#prompt-textarea");
  textarea.value = text;
  const event = new Event("input", { bubbles: true });
  textarea.dispatchEvent(event);

  console.log("Before event dispatching");
  textarea.dispatchEvent(new KeyboardEvent("keydown", {
    bubbles: true,
    cancelable: true,
    keyCode: 13,
  }));
  console.log("After event dispatching");
}

// Periodically check if the button has been added to the page and add it if it hasn't
const targetSelector = "#__next > div.overflow-hidden.w-full.h-full.relative.flex.z-0 > div.relative.flex.h-full.max-w-full.flex-1.overflow-hidden > div > main > div.absolute.bottom-0.left-0.w-full.border-t.md\\:border-t-0.dark\\:border-white\\/20.md\\:border-transparent.md\\:dark\\:border-transparent.md\\:bg-vert-light-gradient.bg-white.dark\\:bg-gray-800.md\\:\\!bg-transparent.dark\\:md\\:bg-vert-dark-gradient.pt-2 > form > div > div";
const intervalId = setInterval(() => {
  const targetElement = document.querySelector(targetSelector);
  if (targetElement && !targetElement.contains(button)) {
    const wrapperDiv = document.createElement("div");
    wrapperDiv.style.display = "flex";
    wrapperDiv.style.flexDirection = "column";

    targetElement.parentNode.insertBefore(wrapperDiv, targetElement.nextSibling);

    wrapperDiv.appendChild(chunkSizeLabel);
    wrapperDiv.appendChild(promptLabel);
    wrapperDiv.appendChild(button);
    wrapperDiv.appendChild(progressContainer);
  }
}, 1000);
